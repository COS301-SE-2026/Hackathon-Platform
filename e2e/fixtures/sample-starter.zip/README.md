starter project readme
